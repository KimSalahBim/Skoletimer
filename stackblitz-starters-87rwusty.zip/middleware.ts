import { NextResponse, type NextRequest } from 'next/server';
import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs';

export async function middleware(req: NextRequest) {
  const res = NextResponse.next();

  const supabase = createMiddlewareClient({ req, res });

  // 1) Hent session
  const {
    data: { session },
  } = await supabase.auth.getSession();

  const pathname = req.nextUrl.pathname;

  const isAuthPage = pathname === '/';
  const isDashboard = pathname.startsWith('/dashboard');
  const isOnboarding = pathname.startsWith('/onboarding');

  // 2) Ikke innlogget → send til login (men ikke hvis du allerede er på login)
  if (!session && (isDashboard || isOnboarding)) {
    const url = req.nextUrl.clone();
    url.pathname = '/';
    return NextResponse.redirect(url);
  }

  // 3) Innlogget → sjekk profil (school_id + rolle) for gating
  if (session && (isDashboard || isOnboarding)) {
    // OBS: Dette forutsetter at du har en tabell "users" (eller view) med kolonnen school_id.
    // Hvis du ikke har "users" enda, så må vi lage den (jeg kan gi SQL).
    const { data: profile, error } = await supabase
      .from('users')
      .select('school_id, role')
      .eq('id', session.user.id)
      .maybeSingle();

    // Hvis tabellen ikke finnes enda, ikke krasj – bare la det passere foreløpig
    if (!error) {
      const hasSchool = !!profile?.school_id;

      // Mangler skole → send til onboarding (men ikke loop)
      if (!hasSchool && isDashboard) {
        const url = req.nextUrl.clone();
        url.pathname = '/onboarding';
        return NextResponse.redirect(url);
      }

      // Har skole → skal ikke være på onboarding
      if (hasSchool && isOnboarding) {
        const url = req.nextUrl.clone();
        url.pathname = '/dashboard';
        return NextResponse.redirect(url);
      }
    }
  }

  return res;
}

export const config = {
  matcher: ['/dashboard/:path*', '/onboarding'],
};
