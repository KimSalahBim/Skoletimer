'use client';

import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/app/lib/supabase';

type TeacherRow = {
  id: string;
  created_at: string;
  name: string;
  email: string;
  position_percentage: number;
  school_id: string | null;
};

type SchoolRow = {
  id: string;
  name: string;
};

type NewTeacherForm = {
  school_id: string;
  name: string;
  email: string;
  position_percentage: number;
};

type EditTeacherForm = {
  id: string;
  school_id: string;
  name: string;
  email: string;
  position_percentage: number;
};

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function friendlyDbError(err: any): string {
  const msg = String(err?.message ?? '');
  const code = String(err?.code ?? '');

  // Postgres unique violation = 23505
  if (
    code === '23505' ||
    msg.includes('duplicate key value') ||
    msg.includes('unique constraint') ||
    msg.includes('teachers_email_key') ||
    msg.includes('teachers_email_unique')
  ) {
    return 'E-postadressen finnes allerede. Velg en annen.';
  }

  return msg || 'Ukjent feil';
}

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState<'oversikt' | 'laerere'>('laerere');

  // Teachers
  const [loadingTeachers, setLoadingTeachers] = useState(false);
  const [teachers, setTeachers] = useState<TeacherRow[]>([]);
  const [teachersError, setTeachersError] = useState<string | null>(null);

  // Schools
  const [loadingSchools, setLoadingSchools] = useState(false);
  const [schools, setSchools] = useState<SchoolRow[]>([]);
  const [schoolsError, setSchoolsError] = useState<string | null>(null);

  // Create modal
  const [isNewTeacherOpen, setIsNewTeacherOpen] = useState(false);
  const [savingTeacher, setSavingTeacher] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [newTeacher, setNewTeacher] = useState<NewTeacherForm>({
    school_id: '',
    name: '',
    email: '',
    position_percentage: 100,
  });

  // Edit modal
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);
  const [editTeacher, setEditTeacher] = useState<EditTeacherForm | null>(null);

  // Delete confirm modal
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [deleteSaving, setDeleteSaving] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [deleteTeacher, setDeleteTeacher] = useState<TeacherRow | null>(null);

  const teacherCount = teachers.length;

  const averagePosition = useMemo(() => {
    if (teachers.length === 0) return 0;
    const sum = teachers.reduce(
      (acc, t) => acc + (t.position_percentage ?? 0),
      0
    );
    return Math.round(sum / teachers.length);
  }, [teachers]);

  const fetchSchools = async (): Promise<SchoolRow[]> => {
    setLoadingSchools(true);
    setSchoolsError(null);
    try {
      const { data, error } = await supabase
        .from('schools')
        .select('id, name')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const rows = (data ?? []) as SchoolRow[];
      setSchools(rows);
      return rows;
    } catch (err: any) {
      console.error('Error fetching schools:', err);
      setSchools([]);
      setSchoolsError(err?.message ?? 'Ukjent feil ved henting av skoler');
      return [];
    } finally {
      setLoadingSchools(false);
    }
  };

  const fetchTeachers = async () => {
    setLoadingTeachers(true);
    setTeachersError(null);
    try {
      const { data, error } = await supabase
        .from('teachers')
        .select('id, created_at, name, email, position_percentage, school_id')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setTeachers((data ?? []) as TeacherRow[]);
    } catch (err: any) {
      console.error('Error fetching teachers:', err);
      setTeachers([]);
      setTeachersError(err?.message ?? 'Ukjent feil ved henting av lærere');
    } finally {
      setLoadingTeachers(false);
    }
  };

  useEffect(() => {
    const init = async () => {
      const schoolRows = await fetchSchools();

      // Velg default school_id hvis mulig
      if (schoolRows.length === 1) {
        setNewTeacher((p) => ({ ...p, school_id: schoolRows[0].id }));
      } else if (schoolRows.length > 0) {
        setNewTeacher((p) =>
          p.school_id ? p : { ...p, school_id: schoolRows[0].id }
        );
      }

      await fetchTeachers();
    };

    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- Create ----------
  const openNewTeacher = () => {
    setSaveError(null);

    let defaultSchoolId = newTeacher.school_id;
    if (!defaultSchoolId) {
      if (schools.length === 1) defaultSchoolId = schools[0].id;
      else if (schools.length > 0) defaultSchoolId = schools[0].id;
      else defaultSchoolId = '';
    }

    setNewTeacher({
      school_id: defaultSchoolId,
      name: '',
      email: '',
      position_percentage: 100,
    });

    setIsNewTeacherOpen(true);
  };

  const closeNewTeacher = () => {
    if (savingTeacher) return;
    setIsNewTeacherOpen(false);
    setSaveError(null);
  };

  const saveNewTeacher = async () => {
    setSaveError(null);

    const school_id = newTeacher.school_id;
    const name = newTeacher.name.trim();
    const email = newTeacher.email.trim().toLowerCase();
    const position = Number(newTeacher.position_percentage);

    if (!school_id) {
      setSaveError('Velg skole før du lagrer.');
      return;
    }
    if (!name) {
      setSaveError('Navn kan ikke være tomt.');
      return;
    }
    if (!email || !isValidEmail(email)) {
      setSaveError('Skriv inn en gyldig e-postadresse.');
      return;
    }
    if (!Number.isFinite(position) || position < 1 || position > 100) {
      setSaveError('Stilling må være et tall mellom 1 og 100.');
      return;
    }

    try {
      setSavingTeacher(true);

      const { error } = await supabase
        .from('teachers')
        .insert([{ school_id, name, email, position_percentage: position }]);

      if (error) throw error;

      setIsNewTeacherOpen(false);
      await fetchTeachers();
    } catch (err: any) {
      console.error('Error inserting teacher:', err);
      setSaveError(friendlyDbError(err));
    } finally {
      setSavingTeacher(false);
    }
  };

  // ---------- Edit ----------
  const openEditTeacher = (t: TeacherRow) => {
    setEditError(null);

    setEditTeacher({
      id: t.id,
      school_id: t.school_id ?? schools[0]?.id ?? '',
      name: t.name ?? '',
      email: (t.email ?? '').toLowerCase(),
      position_percentage: Number(t.position_percentage ?? 100),
    });

    setIsEditOpen(true);
  };

  const closeEditTeacher = () => {
    if (editSaving) return;
    setIsEditOpen(false);
    setEditError(null);
    setEditTeacher(null);
  };

  const saveEditTeacher = async () => {
    if (!editTeacher) return;

    setEditError(null);

    const id = editTeacher.id;
    const school_id = editTeacher.school_id;
    const name = editTeacher.name.trim();
    const email = editTeacher.email.trim().toLowerCase();
    const position = Number(editTeacher.position_percentage);

    if (!school_id) {
      setEditError('Velg skole før du lagrer.');
      return;
    }
    if (!name) {
      setEditError('Navn kan ikke være tomt.');
      return;
    }
    if (!email || !isValidEmail(email)) {
      setEditError('Skriv inn en gyldig e-postadresse.');
      return;
    }
    if (!Number.isFinite(position) || position < 1 || position > 100) {
      setEditError('Stilling må være et tall mellom 1 og 100.');
      return;
    }

    try {
      setEditSaving(true);

      const { error } = await supabase
        .from('teachers')
        .update({
          school_id,
          name,
          email,
          position_percentage: position,
        })
        .eq('id', id);

      if (error) throw error;

      setIsEditOpen(false);
      setEditTeacher(null);
      await fetchTeachers();
    } catch (err: any) {
      console.error('Error updating teacher:', err);
      setEditError(friendlyDbError(err));
    } finally {
      setEditSaving(false);
    }
  };

  // ---------- Delete ----------
  const openDeleteTeacher = (t: TeacherRow) => {
    setDeleteError(null);
    setDeleteTeacher(t);
    setIsDeleteOpen(true);
  };

  const closeDeleteTeacher = () => {
    if (deleteSaving) return;
    setIsDeleteOpen(false);
    setDeleteError(null);
    setDeleteTeacher(null);
  };

  const confirmDeleteTeacher = async () => {
    if (!deleteTeacher) return;

    try {
      setDeleteSaving(true);
      setDeleteError(null);

      const { error } = await supabase
        .from('teachers')
        .delete()
        .eq('id', deleteTeacher.id);
      if (error) throw error;

      setIsDeleteOpen(false);
      setDeleteTeacher(null);
      await fetchTeachers();
    } catch (err: any) {
      console.error('Error deleting teacher:', err);
      setDeleteError(err?.message ?? 'Kunne ikke slette lærer');
    } finally {
      setDeleteSaving(false);
    }
  };

  // ---------- UI ----------
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="mx-auto max-w-5xl px-4 py-8">
        <header className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">Skoletimer – admin og oversikt</p>
        </header>

        <div className="mb-6 flex gap-2">
          <button
            onClick={() => setActiveTab('oversikt')}
            className={`rounded-lg px-4 py-2 text-sm font-medium ${
              activeTab === 'oversikt'
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-700 border border-gray-200'
            }`}
          >
            Oversikt
          </button>

          <button
            onClick={() => setActiveTab('laerere')}
            className={`rounded-lg px-4 py-2 text-sm font-medium ${
              activeTab === 'laerere'
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-700 border border-gray-200'
            }`}
          >
            Lærere
          </button>
        </div>

        {activeTab === 'oversikt' && (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="rounded-xl border border-gray-200 bg-white p-5">
              <div className="text-sm text-gray-500">Antall lærere</div>
              <div className="mt-2 text-3xl font-bold text-gray-900">
                {teacherCount}
              </div>
            </div>
            <div className="rounded-xl border border-gray-200 bg-white p-5">
              <div className="text-sm text-gray-500">
                Gjennomsnitt stilling (%)
              </div>
              <div className="mt-2 text-3xl font-bold text-gray-900">
                {averagePosition}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'laerere' && (
          <div className="rounded-xl border border-gray-200 bg-white p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Lærere</h2>

              <div className="flex items-center gap-2">
                <button
                  onClick={fetchTeachers}
                  className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                >
                  Oppdater
                </button>

                <button
                  onClick={openNewTeacher}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
                >
                  + Ny lærer
                </button>
              </div>
            </div>

            {(loadingSchools || schoolsError) && (
              <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 p-4 text-amber-800">
                {loadingSchools && <div>Laster skoler…</div>}
                {!loadingSchools && schoolsError && (
                  <div>Klarte ikke hente skoler: {schoolsError}</div>
                )}
              </div>
            )}

            {loadingTeachers && (
              <div className="rounded-lg bg-gray-50 p-4 text-gray-700">
                Laster lærere…
              </div>
            )}

            {!loadingTeachers && teachersError && (
              <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-red-700">
                Feil ved henting av lærere: {teachersError}
              </div>
            )}

            {!loadingTeachers && !teachersError && teachers.length === 0 && (
              <div className="rounded-lg bg-gray-50 p-4 text-gray-700">
                Ingen lærere funnet.
              </div>
            )}

            {!loadingTeachers && !teachersError && teachers.length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b border-gray-200 text-left text-sm text-gray-600">
                      <th className="py-2 pr-4">Navn</th>
                      <th className="py-2 pr-4">E-post</th>
                      <th className="py-2 pr-4">Stilling</th>
                      <th className="py-2 pr-4">Opprettet</th>
                      <th className="py-2 pr-0 text-right">Handling</th>
                    </tr>
                  </thead>
                  <tbody>
                    {teachers.map((t) => (
                      <tr
                        key={t.id}
                        className="border-b border-gray-100 text-sm"
                      >
                        <td className="py-3 pr-4 font-medium text-gray-900">
                          {t.name}
                        </td>
                        <td className="py-3 pr-4 text-gray-700">{t.email}</td>
                        <td className="py-3 pr-4 text-gray-700">
                          {t.position_percentage}%
                        </td>
                        <td className="py-3 pr-4 text-gray-500">
                          {new Date(t.created_at).toLocaleString('no-NO')}
                        </td>
                        <td className="py-3 pr-0 text-right">
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => openEditTeacher(t)}
                              className="rounded-lg border border-gray-200 bg-white px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-50"
                            >
                              Rediger
                            </button>
                            <button
                              onClick={() => openDeleteTeacher(t)}
                              className="rounded-lg border border-red-200 bg-white px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50"
                            >
                              Slett
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* ---------- Create modal ---------- */}
            {isNewTeacherOpen && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
                <div className="w-full max-w-lg rounded-xl bg-white p-5 shadow-lg">
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">
                      Ny lærer
                    </h3>
                    <button
                      onClick={closeNewTeacher}
                      className="rounded-md px-2 py-1 text-sm text-gray-600 hover:bg-gray-100"
                      aria-label="Lukk"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="mb-1 block text-sm font-medium text-gray-700">
                        Skole
                      </label>
                      {schools.length > 0 ? (
                        <select
                          value={newTeacher.school_id}
                          onChange={(e) =>
                            setNewTeacher((p) => ({
                              ...p,
                              school_id: e.target.value,
                            }))
                          }
                          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                          disabled={savingTeacher}
                        >
                          <option value="">Velg skole…</option>
                          {schools.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          value={newTeacher.school_id}
                          onChange={(e) =>
                            setNewTeacher((p) => ({
                              ...p,
                              school_id: e.target.value,
                            }))
                          }
                          placeholder="Lim inn school_id"
                          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                          disabled={savingTeacher}
                        />
                      )}
                    </div>

                    <div>
                      <label className="mb-1 block text-sm font-medium text-gray-700">
                        Navn
                      </label>
                      <input
                        value={newTeacher.name}
                        onChange={(e) =>
                          setNewTeacher((p) => ({ ...p, name: e.target.value }))
                        }
                        placeholder="F.eks. Ola Nordmann"
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                        disabled={savingTeacher}
                      />
                    </div>

                    <div>
                      <label className="mb-1 block text-sm font-medium text-gray-700">
                        E-post
                      </label>
                      <input
                        value={newTeacher.email}
                        onChange={(e) =>
                          setNewTeacher((p) => ({
                            ...p,
                            email: e.target.value,
                          }))
                        }
                        placeholder="ola@skole.no"
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                        disabled={savingTeacher}
                      />
                    </div>

                    <div>
                      <label className="mb-1 block text-sm font-medium text-gray-700">
                        Stilling (%)
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={newTeacher.position_percentage}
                        onChange={(e) =>
                          setNewTeacher((p) => ({
                            ...p,
                            position_percentage: Number(e.target.value),
                          }))
                        }
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                        disabled={savingTeacher}
                      />
                    </div>

                    {saveError && (
                      <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                        {saveError}
                      </div>
                    )}
                  </div>

                  <div className="mt-5 flex justify-end gap-2">
                    <button
                      onClick={closeNewTeacher}
                      className="rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                      disabled={savingTeacher}
                    >
                      Avbryt
                    </button>
                    <button
                      onClick={saveNewTeacher}
                      className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-60"
                      disabled={savingTeacher}
                    >
                      {savingTeacher ? 'Lagrer…' : 'Lagre lærer'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ---------- Edit modal ---------- */}
            {isEditOpen && editTeacher && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
                <div className="w-full max-w-lg rounded-xl bg-white p-5 shadow-lg">
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">
                      Rediger lærer
                    </h3>
                    <button
                      onClick={closeEditTeacher}
                      className="rounded-md px-2 py-1 text-sm text-gray-600 hover:bg-gray-100"
                      aria-label="Lukk"
                    >
                      ✕
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="mb-1 block text-sm font-medium text-gray-700">
                        Skole
                      </label>
                      {schools.length > 0 ? (
                        <select
                          value={editTeacher.school_id}
                          onChange={(e) =>
                            setEditTeacher((p) =>
                              p ? { ...p, school_id: e.target.value } : p
                            )
                          }
                          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                          disabled={editSaving}
                        >
                          <option value="">Velg skole…</option>
                          {schools.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          value={editTeacher.school_id}
                          onChange={(e) =>
                            setEditTeacher((p) =>
                              p ? { ...p, school_id: e.target.value } : p
                            )
                          }
                          placeholder="Lim inn school_id"
                          className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                          disabled={editSaving}
                        />
                      )}
                    </div>

                    <div>
                      <label className="mb-1 block text-sm font-medium text-gray-700">
                        Navn
                      </label>
                      <input
                        value={editTeacher.name}
                        onChange={(e) =>
                          setEditTeacher((p) =>
                            p ? { ...p, name: e.target.value } : p
                          )
                        }
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                        disabled={editSaving}
                      />
                    </div>

                    <div>
                      <label className="mb-1 block text-sm font-medium text-gray-700">
                        E-post
                      </label>
                      <input
                        value={editTeacher.email}
                        onChange={(e) =>
                          setEditTeacher((p) =>
                            p ? { ...p, email: e.target.value } : p
                          )
                        }
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                        disabled={editSaving}
                      />
                    </div>

                    <div>
                      <label className="mb-1 block text-sm font-medium text-gray-700">
                        Stilling (%)
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={100}
                        value={editTeacher.position_percentage}
                        onChange={(e) =>
                          setEditTeacher((p) =>
                            p
                              ? {
                                  ...p,
                                  position_percentage: Number(e.target.value),
                                }
                              : p
                          )
                        }
                        className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:border-indigo-500"
                        disabled={editSaving}
                      />
                    </div>

                    {editError && (
                      <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                        {editError}
                      </div>
                    )}
                  </div>

                  <div className="mt-5 flex justify-end gap-2">
                    <button
                      onClick={closeEditTeacher}
                      className="rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                      disabled={editSaving}
                    >
                      Avbryt
                    </button>
                    <button
                      onClick={saveEditTeacher}
                      className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-60"
                      disabled={editSaving}
                    >
                      {editSaving ? 'Lagrer…' : 'Lagre endringer'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ---------- Delete confirm modal ---------- */}
            {isDeleteOpen && deleteTeacher && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
                <div className="w-full max-w-md rounded-xl bg-white p-5 shadow-lg">
                  <div className="mb-3 flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">
                      Slett lærer
                    </h3>
                    <button
                      onClick={closeDeleteTeacher}
                      className="rounded-md px-2 py-1 text-sm text-gray-600 hover:bg-gray-100"
                      aria-label="Lukk"
                    >
                      ✕
                    </button>
                  </div>

                  <p className="text-sm text-gray-700">
                    Er du sikker på at du vil slette{' '}
                    <span className="font-semibold">{deleteTeacher.name}</span>?
                  </p>
                  <p className="mt-1 text-xs text-gray-500">
                    Dette kan ikke angres.
                  </p>

                  {deleteError && (
                    <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                      {deleteError}
                    </div>
                  )}

                  <div className="mt-5 flex justify-end gap-2">
                    <button
                      onClick={closeDeleteTeacher}
                      className="rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                      disabled={deleteSaving}
                    >
                      Avbryt
                    </button>
                    <button
                      onClick={confirmDeleteTeacher}
                      className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 disabled:opacity-60"
                      disabled={deleteSaving}
                    >
                      {deleteSaving ? 'Sletter…' : 'Slett'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
