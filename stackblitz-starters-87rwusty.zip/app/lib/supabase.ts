import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://cknxbldlihejcpepjtgi.supabase.co';
const supabaseAnonKey =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNrbnhibGRsaWhlamNwZXBqdGdpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg1OTU1ODgsImV4cCI6MjA4NDE3MTU4OH0.x375FWlUIJOTjzEQ3nel8VX9gYXI60PJArpmV26CBYE';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
